Place your images here:
- z-devs-logo.png
- salvatore.png
- samir.png
- blackhole-bg.jpg (optional)
