# Zeni Devs — Official Website

**Z Devs** · BUILD. CREATE. INNOVATE.

Premium cinematic website for the Zeni Devs developer community.

---

## Project Structure

```
Z-Devs/
├── index.html
├── style.css
├── script.js
├── README.md
└── images/
    ├── z-devs-logo.png      ← Your logo
    ├── salvatore.png        ← Salvatore profile photo
    ├── samir.png            ← Samir profile photo
    └── blackhole-bg.jpg     ← Optional custom black-hole image
```

---

## Adding Your Images (Required)

Place your image files in the `images/` folder with **exact** filenames:

| File | Purpose |
|------|---------|
| `images/z-devs-logo.png` | Navigation + Footer logo |
| `images/salvatore.png` | Salvatore founder photo |
| `images/samir.png` | Samir founder photo |
| `images/blackhole-bg.jpg` | Optional custom background (current design uses pure CSS) |

**Important:**
- The website works even if images are missing (graceful CSS fallbacks with initials).
- No code changes are needed when you add the images.
- Recommended sizes:
  - Logo: 128×128 or 256×256 PNG (transparent preferred)
  - Profile photos: 400×400 or larger square PNG/JPG
  - Black-hole: 1920×1080 or larger (only if you want to replace the CSS version)

---

## How to Preview Locally

### On a Computer
1. Extract the ZIP.
2. Open the `Z-Devs` folder.
3. Double-click `index.html` or open it in any browser (Chrome, Firefox, Edge, Safari).

### On Android Phone
1. Extract the ZIP using Files, ZArchiver, or RAR.
2. Open the extracted `Z-Devs` folder.
3. Tap `index.html` → choose Chrome or any browser.

---

## Deploy to Vercel (Recommended)

1. Go to [vercel.com](https://vercel.com) and sign in.
2. Click **Add New Project**.
3. Import the `Z-Devs` folder (or connect a GitHub repository containing it).
4. Framework Preset: **Other**.
5. Click **Deploy**.

Your site will be live in seconds.

Alternative: Netlify, GitHub Pages, or any static host works the same way.

---

## Features Included

- Cinematic black-hole CSS background (Interstellar-inspired)
- Floating glass navigation with mobile hamburger menu
- Hero with gradient text and smooth animations
- About section with 3 feature cards
- Founders section (Salvatore & Samir) with Discord profile links
- Projects showcase (EclipseX, xyro, AuviX, Nexora Music)
- Technology stack display
- Contact / Community section with Discord invite
- Fully responsive (320px → 1440px+)
- Accessibility: keyboard navigation, focus states, reduced-motion support
- Performance-focused (no heavy libraries)

---

## Discord Links (Already Configured)

- Support Server: https://discord.gg/E6P757sg77
- Salvatore Profile: https://discord.com/users/1109714278640001054
- Samir Profile: https://discord.com/users/1537413650283765810

---

## Brand Colors

- Background: `#050505` / `#0A0A0F`
- Purple: `#8B5CF6` / `#A855F7`
- Cyan: `#22D3EE`
- Text: `#F5F5F5` / `#A1A1AA`

---

© Zeni Devs · Built with creativity and code.
